#require 'rubygems'
#gem 'soap4r'
#require 'soap/rpc/driver' 
#require 'soap/wsdlDriver'
#require File.dirname(__FILE__) + '/../models/content_struct.rb'
require 'rubygems'
gem 'actionwebservice'

#------------------------------------------
#WSDL_URL = "http://localhost:4000/slide_show_service/service.wsdl"
#soap = SOAP::WSDLDriverFactory.new(WSDL_URL).createDriver
#------------------------------------------
#WSDL_URL = "http://localhost:4000/slide_show_service/api"
#soap = ActionWebService::Client::Soap.new(SlideShowServiceApi, WSDL_URL)
#------------------------------------------
WSDL_URL = "http://localhost:4000/slide_show_service/api"
soap = ActionWebService::Client::Soap.new(SlideShowServiceApi, WSDL_URL)
#------------------------------------------
puts "=============== client test ==================="

slide_arr = []

content = {:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg']}
slide = {:name => 'TestSlidePhoto', :description => 'Photo Description', :content_num => 1, :contents => [content]}
slide_arr << slide;

content = {:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg']}
slide = {:name => 'TestSlideVideo', :description => 'Video Description', :content_num => 1, :contents => [content]}
slide_arr << slide;

content = {:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg']}
slide = {:name => 'TestSlideFlash', :description => 'Flash Description', :content_num => 1, :contents => [content]}
slide_arr << slide;
 
slide_show = {:title => 'TestSlideShow', :submitter => 'Tester', :slide_num => 3, :slides => slide_arr}


#str = soap.export_ppt(slide_show)

arr = ["roy", "fhu"]
str = soap.export_ppt(arr)
puts str

def create_slideshow_struct
  pres = {}
#  slideshow = Slideshow.find(params[:id])
#  pres["title"] = slideshow.name
#  pres["submitter"] = User.find(slideshow.submitter_id).name
#  slides = slideshow.slides
#  pres["slide_num"] = slides.size
#  slide_arr = []
#  for slide in slides
#    slide_struct = {}
#    slide_struct["name"] = slide.name
#    slide_struct["description"] = "no description currently" #there may be some description in future
#    slide_struct["content_num"] = 1 # one slide only contain one content,currently
#    content_arr = []
#    content_struct = {}
#    if slide.photo
#      content_struct["type"] = "photo" #in phase 1,we only supports photo
#      content_struct["source_num"] = 1 #one photo currently
#      content_struct["sources"] = ["#{slide.photo.path}"]
#      content_arr << content_struct
#      slide_struct["contents"] = content_arr
#      slide_arr << slide_struct
#    else
#      # skip viedo now, so do nothing but decrease the number of slide   
#      pres["slide_num"]-=1
#    end
#  end
  pres["slides"] = slide_arr
  return pres
end