class PptServiceApi < ActionWebService::API::Base  
  api_method :export_ppt,
             :expects => [Presentation],
             :returns => [:string]
end


#http://www.youtube.com/?v=nZ89ZUZcHYc
#http://img.youtube.com/vi/nZ89ZUZcHYc/default.jpg