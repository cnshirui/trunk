require File.dirname(__FILE__) + '/../test_helper'

class SlideShowServiceController; def rescue_action(e) raise e end; end

class SlideShowServiceControllerApiTest < Test::Unit::TestCase
  
  def setup
    @controller = SlideShowServiceController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_export_ppt
    
    slide_arr = []
    
    content = Content_struct.new(:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg'])
    slide = Slide_struct.new(:name => 'TestPhoto', :description => 'Photo Description', :content_num => 1, :contents => [content])
    slide_arr << slide;
    
    content = Content_struct.new(:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg'])
    slide = Slide_struct.new(:name => 'TestVideo', :description => 'Video Description', :content_num => 1, :contents => [content])
    slide_arr << slide;
    
    content = Content_struct.new(:type => 'photo', :source_num => 1, :sources => ['http://static.flickr.com/1040/1355638986_3c8713ddca.jpg'])
    slide = Slide_struct.new(:name => 'TestFlash', :description => 'Flash Description', :content_num => 1, :contents => [content])
    slide_arr << slide;
   
    slide_show = Slide_show_struct.new(:title => 'TestSlide', :submitter => 'Tester', :slide_num => 3, :slides => slide_arr)
 
    result = invoke :export_ppt, slide_show
    assert_equal("files/TestSlide.ppt", result)
  end
end
