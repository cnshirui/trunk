-- MySQL dump 10.11
--
-- Host: localhost    Database: depot_development
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `line_items`
--

DROP TABLE IF EXISTS `line_items`;
CREATE TABLE `line_items` (
  `id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(8,2) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_line_item_products` (`product_id`),
  KEY `fk_line_item_orders` (`order_id`),
  CONSTRAINT `fk_line_item_orders` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `fk_line_item_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `line_items`
--

LOCK TABLES `line_items` WRITE;
/*!40000 ALTER TABLE `line_items` DISABLE KEYS */;
INSERT INTO `line_items` VALUES (1,2,1,2,'59.90'),(2,4,1,1,'27.75'),(3,2,2,3,'89.85'),(4,4,2,1,'27.75'),(5,3,2,1,'28.50'),(6,2,3,2,'59.90'),(7,4,3,1,'27.75');
/*!40000 ALTER TABLE `line_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `email` varchar(255) default NULL,
  `pay_type` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'Roy Shi','Shanghai','shiruide@gmail.com','po'),(2,'Shi Rui','rudong','cnshirui@hotmail.com','check'),(3,'shirui','jiangsu','shirui@bobj.com','po');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `description` text,
  `image_url` varchar(255) default NULL,
  `price` decimal(8,2) default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (2,'Pragmatic Project Automation','<p>\n       <em>Pragmatic Project Automation</em> shows you how to improve the \n       consistency and repeatability of your project\'s procedures using \n       automation to reduce risk and errors.\n      </p>\n      <p>\n        Simply put, we\'re going to put this thing called a computer to work \n        for you doing the mundane (but important) project stuff. That means \n        you\'ll have more time and energy to do the really \n        exciting---and difficult---stuff, like writing quality code.\n      </p>','/images/auto.jpg','29.95'),(3,'Pragmatic Version Control','<p>\n         This book is a recipe-based approach to using Subversion that will \n         get you up and running quickly---and correctly. All projects need\n         version control: it\'s a foundational piece of any project\'s \n         infrastructure. Yet half of all project teams in the U.S. don\'t use\n         any version control at all. Many others don\'t use it well, and end \n         up experiencing time-consuming problems.\n      </p>','/images/svn.jpg','28.50'),(4,'Pragmatic Unit Testing (C#)','<p>\n        Pragmatic programmers use feedback to drive their development and \n        personal processes. The most valuable feedback you can get while \n        coding comes from unit testing.\n      </p>\n      <p>\n        Without good tests in place, coding can become a frustrating game of \n        \"whack-a-mole.\" That\'s the carnival game where the player strikes at a \n        mechanical mole; it retreats and another mole pops up on the opposite side \n        of the field. The moles pop up and down so fast that you end up flailing \n        your mallet helplessly as the moles continue to pop up where you least \n        expect them.\n      </p>','/images/utc.jpg','27.75');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `text` text,
  `score` int(11) default NULL,
  `author` varchar(120) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_info`
--

DROP TABLE IF EXISTS `schema_info`;
CREATE TABLE `schema_info` (
  `version` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schema_info`
--

LOCK TABLES `schema_info` WRITE;
/*!40000 ALTER TABLE `schema_info` DISABLE KEYS */;
INSERT INTO `schema_info` VALUES (7);
/*!40000 ALTER TABLE `schema_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL auto_increment,
  `session_id` varchar(255) default NULL,
  `data` text,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_sessions_on_session_id` (`session_id`),
  KEY `index_sessions_on_updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (16,'0f2031350f0161ce8889daa25dab8d06','BAh7CDoJY2FydG86CUNhcnQGOgtAaXRlbXNbADoMdXNlcl9pZGkIIgpmbGFz\naElDOidBY3Rpb25Db250cm9sbGVyOjpGbGFzaDo6Rmxhc2hIYXNoewAGOgpA\ndXNlZHsA\n','2007-08-19 10:58:39'),(17,'283e2d61048fe7cf5373884c34ffec68','BAh7BiIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo\nSGFzaHsABjoKQHVzZWR7AA==\n','2007-08-19 11:06:30'),(18,'e1eb4d12d190d2680bc9e86599afac62','BAh7CDoJY2FydG86CUNhcnQGOgtAaXRlbXNbBm86DUNhcnRJdGVtBzoOQHF1\nYW50aXR5aQY6DUBwcm9kdWN0bzoMUHJvZHVjdAY6EEBhdHRyaWJ1dGVzewoi\nDmltYWdlX3VybCIVL2ltYWdlcy9hdXRvLmpwZyIKcHJpY2UiCjI5Ljk1Igp0\naXRsZSIhUHJhZ21hdGljIFByb2plY3QgQXV0b21hdGlvbiIHaWQiBjIiEGRl\nc2NyaXB0aW9uIgL+ATxwPgogICAgICAgPGVtPlByYWdtYXRpYyBQcm9qZWN0\nIEF1dG9tYXRpb248L2VtPiBzaG93cyB5b3UgaG93IHRvIGltcHJvdmUgdGhl\nIAogICAgICAgY29uc2lzdGVuY3kgYW5kIHJlcGVhdGFiaWxpdHkgb2YgeW91\nciBwcm9qZWN0J3MgcHJvY2VkdXJlcyB1c2luZyAKICAgICAgIGF1dG9tYXRp\nb24gdG8gcmVkdWNlIHJpc2sgYW5kIGVycm9ycy4KICAgICAgPC9wPgogICAg\nICA8cD4KICAgICAgICBTaW1wbHkgcHV0LCB3ZSdyZSBnb2luZyB0byBwdXQg\ndGhpcyB0aGluZyBjYWxsZWQgYSBjb21wdXRlciB0byB3b3JrIAogICAgICAg\nIGZvciB5b3UgZG9pbmcgdGhlIG11bmRhbmUgKGJ1dCBpbXBvcnRhbnQpIHBy\nb2plY3Qgc3R1ZmYuIFRoYXQgbWVhbnMgCiAgICAgICAgeW91J2xsIGhhdmUg\nbW9yZSB0aW1lIGFuZCBlbmVyZ3kgdG8gZG8gdGhlIHJlYWxseSAKICAgICAg\nICBleGNpdGluZy0tLWFuZCBkaWZmaWN1bHQtLS1zdHVmZiwgbGlrZSB3cml0\naW5nIHF1YWxpdHkgY29kZS4KICAgICAgPC9wPjoMdXNlcl9pZGkKIgpmbGFz\naElDOidBY3Rpb25Db250cm9sbGVyOjpGbGFzaDo6Rmxhc2hIYXNoewAGOgpA\ndXNlZHsA\n','2007-11-19 22:11:28');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `hashed_password` varchar(255) default NULL,
  `salt` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'cnshirui','511df36622eedcf475d26d72dddb8768029366f7','379293500.950681631025744'),(4,'shirui','511df36622eedcf475d26d72dddb8768029366f7','385488200.560261166793737'),(5,'dave','a7c2fe4929019660a030d11a4cfc748413239e30','383752900.719651932635732');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2007-11-19 14:12:50
