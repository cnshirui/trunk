require 'test_helper'

class DataHelperTest < ActionView::TestCase
end
