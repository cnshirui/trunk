# Django settings for the example project.

DEBUG = True
TEMPLATE_DEBUG = DEBUG
ROOT_URLCONF = 'examples.urls'
