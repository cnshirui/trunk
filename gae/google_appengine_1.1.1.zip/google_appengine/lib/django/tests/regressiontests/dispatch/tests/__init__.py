"""
Unit-tests for the dispatch project
"""

from test_dispatcher import *
from test_robustapply import *
from test_saferef import *
