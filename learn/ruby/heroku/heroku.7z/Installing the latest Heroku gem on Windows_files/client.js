/* Javascript functions that are dependant on translation locales */

function i18n_distance_of_time_in_words(to, from) {
  seconds_ago = ((to  - from) / 1000);
  minutes_ago = Math.floor(seconds_ago / 60)

  if(minutes_ago <= 0) { return "less than a minute";}
  if(minutes_ago == 1) { return "1 minute";}
  if(minutes_ago < 45) { return "XXX minutes".gsub('XXX', minutes_ago);}
  if(minutes_ago < 90) { return "about 1 hour";}
  hours_ago  = Math.round(minutes_ago / 60);
  if(minutes_ago < 1440) { return "about XXX hours".gsub('XXX', hours_ago);}
  if(minutes_ago < 2880) { return "1 day";}
  days_ago  = Math.round(minutes_ago / 1440);
  if(minutes_ago < 43200) { return "XXX days".gsub('XXX', days_ago);}
  if(minutes_ago < 86400) { return "about 1 month";}
  months_ago  = Math.round(minutes_ago / 43200);
  if(minutes_ago < 525960) { return "about XXX months".gsub('XXX', months_ago);}
  if(minutes_ago < 1051920) { return "about 1 year";}
  years_ago  = Math.round(minutes_ago / 525960);
  return "over XXX years".gsub('XXX', years_ago)
}