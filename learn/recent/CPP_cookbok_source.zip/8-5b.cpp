// Static.cpp
#include "Static.h"

int OneStatic::count = 0;

OneStatic::OneStatic( ) {
   count++;
}
