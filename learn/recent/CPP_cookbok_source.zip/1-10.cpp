install target-name
   : files
   : requirements
   : default-build
   : usage-requirements
   ;
