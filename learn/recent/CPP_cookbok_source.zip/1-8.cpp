# jamfile for project hello

exe hello : hello.cpp ;

install dist : hello : <location>. ;
