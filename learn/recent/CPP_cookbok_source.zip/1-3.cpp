// hellobeatles/ hellobeatles.cpp
#include "johnpaul/johnpaul.hpp"
#include "georgeringo/georgeringo.hpp"

int main( )
{
   // Prints "John, Paul, George, and Ringo\n"
   johnpaul( );
   georgeringo( );
}
