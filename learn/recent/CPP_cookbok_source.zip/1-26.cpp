#ifndef JOHNPAUL_HPP_INCLUDED
#define JOHNPAUL_HPP_INCLUDED
#pragma comment(lib, "libjohnpaul")

void johnpaul( );

#endif // JOHNPAUL_HPP_INCLUDED
