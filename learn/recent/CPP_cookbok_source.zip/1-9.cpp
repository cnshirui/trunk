exe target-name
   : sources
   : requirements
   : default-build
   : usage-requirements
   ;
