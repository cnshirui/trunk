/**
 * Copyright 2007 Ye Zheng
 * Distributed under the GNU General Public License 2.0
 */

package com.xruby.runtime.lang.util;

import org.objectweb.asm.commons.GeneratorAdapter;
import org.objectweb.asm.commons.Method;

import com.xruby.compiler.codegen.CgUtil;
import com.xruby.compiler.codegen.Types;

public class VarArgRunMethodHelper extends RunMethodHelper {
	private static final Method VarArgRunMethod = CgUtil.getMethod("run", Types.RUBY_VALUE_TYPE, Types.RUBY_VALUE_TYPE,
			Types.RUBY_ARRAY_TYPE, Types.RUBY_BLOCK_TYPE);
	
	protected Method getRunMethod() {
		return VarArgRunMethod;
	}
	
	protected void loadBlock(GeneratorAdapter mg) {
		mg.loadArg(2);
	}
	
	protected int rubyArgSize() {
		return -1;
	}

	protected void loadArgs(GeneratorAdapter mg) {
		mg.loadArg(1);
	}
}
