package com.xruby.runtime.lang.util;

import com.xruby.runtime.lang.RubyObject;

public interface RubyObjectBuilder {
	RubyObject createRubyObject();
}
