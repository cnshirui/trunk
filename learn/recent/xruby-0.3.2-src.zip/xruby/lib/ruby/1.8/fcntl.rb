#cruby implemented this module in c: fcntl.so

module Fcntl
end