
This folder is used to store files used for demo
