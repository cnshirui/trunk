package com.xruby.compiler.codegen;

import org.objectweb.asm.Opcodes;

public class CgConfig {
	public static final int TARGET_VERSION = Opcodes.V1_5;
	
	private CgConfig() {}
}
