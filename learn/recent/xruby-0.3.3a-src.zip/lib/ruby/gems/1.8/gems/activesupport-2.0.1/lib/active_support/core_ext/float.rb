require 'active_support/core_ext/float/rounding'

class Float #:nodoc:
  include ActiveSupport::CoreExtensions::Float::Rounding
end
