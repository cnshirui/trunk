require 'active_support/core_ext/object/extending'
require 'active_support/core_ext/object/instance_variables'
require 'active_support/core_ext/object/misc'
