#This is an empty file. 
#XRuby implements StringIO in java 
