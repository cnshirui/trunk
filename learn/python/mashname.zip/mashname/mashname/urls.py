from django.conf.urls.defaults import *

urlpatterns = patterns('',
    (r'^$', 'mashname.main.views.main'),
    # Example:
    # (r'^mashname/', include('mashname.foo.urls')),

    # Uncomment this for admin:
#     (r'^admin/', include('django.contrib.admin.urls')),
)
